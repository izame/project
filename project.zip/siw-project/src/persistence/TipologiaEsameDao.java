package persistence;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import model.TipologiaEsame;

public class TipologiaEsameDao implements Dao<TipologiaEsame> {
	

	private EntityManager em;

	public TipologiaEsameDao(EntityManager em) {
		this.em = em;
	}

	public void save(TipologiaEsame c) {
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		em.persist(c);
		tx.commit();
	}

	public TipologiaEsame findByPrimaryKey(String code) {
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		TipologiaEsame c = em.find(TipologiaEsame.class, code);
		tx.commit();
		return c;
	}

	public void delete(TipologiaEsame c) {
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		TipologiaEsame toRemove = em.merge(c);
		em.remove(toRemove);
		tx.commit();		
	}

	public void update(TipologiaEsame c) {
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		em.merge(c);
		tx.commit();
	}

	public List<TipologiaEsame> findAll() {
		List<TipologiaEsame> result =  new ArrayList<>(em.createNamedQuery("TipologiaEsame.findAll",TipologiaEsame.class).getResultList());
		return result;
	}

	public void closeEmf() {
		em.close();
	}
	
	
	

}