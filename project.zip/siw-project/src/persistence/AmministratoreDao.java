package persistence;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;


import model.Amministratore;


public class AmministratoreDao implements Dao<Amministratore>{
	private EntityManager em;

	public AmministratoreDao(EntityManager em) {
		this.em = em;
	}

	public void save(Amministratore c) {
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		em.persist(c);
		tx.commit();
	}

	public Amministratore findByPrimaryKey(String mail){
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		Amministratore c = em.find(Amministratore.class, mail);
		tx.commit();
		return c;
	}
	
	public void delete(Amministratore c) {
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		Amministratore toRemove = em.merge(c);
		em.remove(toRemove);
		tx.commit();		
	}

	public void update(Amministratore c) {
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		em.merge(c);
		tx.commit();
	}

	public List<Amministratore> findAll() {
	List<Amministratore> result = em.createNamedQuery("Amministratore.findAll",Amministratore.class).getResultList();
		return result;
	}

	public void closeEmf() {
		em.close();
	}

}





