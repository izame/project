package persistence;

import java.util.List;

public interface Dao<T> {
	
	public void save(T entity);
	
	public void update(T entity);
	
	public T findByPrimaryKey(String code);
	
	public void delete(T entity);
	
	public List<T> findAll();

}