package persistence;


import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import model.Esame;


public class EsameDao implements Dao<Esame> {
	private EntityManager em;

	public EsameDao(EntityManager em) {
		this.em = em;
	}

	public void save(Esame o) {
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		em.persist(o);
		tx.commit();
	}

	public Esame findByPrimaryKey(String code) {
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		Esame c = em.find(Esame.class, code);
		tx.commit();
		return c;
	}
	
	public Esame findByIdMedico(long id){
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		Esame c = em.find(Esame.class, id);
		tx.commit();
		return c;
	}

	public void delete(Esame o) {
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		Esame toRemove = em.merge(o);
		em.remove(toRemove);
		tx.commit();		
	}

	public void update(Esame o) {
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		em.merge(o);
		tx.commit();
	}

	public List<Esame> findAll() {
		List<Esame> result = em.createNamedQuery("Esame.findAll",Esame.class).getResultList();
		return result;
	}

	
	


}