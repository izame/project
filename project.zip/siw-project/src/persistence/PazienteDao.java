package persistence;



import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import model.Paziente;

public class PazienteDao implements Dao<Paziente> {
	
	private EntityManager em;

	public PazienteDao(EntityManager em) {
		this.em = em;
	}

	public void save(Paziente c) {
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		em.persist(c);
		tx.commit();
	}

	public Paziente findByPrimaryKey(String taxCode) {
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		Paziente c = em.find(Paziente.class, taxCode);
		tx.commit();
		return c;
	}
	public Paziente findByCodiceFiscale(String cf) {
		Query query =em.createNamedQuery("Paziente.findByCodiceFiscale");
		query.setParameter("codiceFiscale", cf);
		return (Paziente)query.getResultList().get(0);
	}

	public void delete(Paziente c) {
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		Paziente toRemove = em.merge(c);
		em.remove(toRemove);
		tx.commit();		
	}

	public void update(Paziente c) {
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		em.merge(c);
		tx.commit();
	}

	public List<Paziente> findAll() {
		List<Paziente> result = em.createNamedQuery("Paziente.findAll",Paziente.class).getResultList();
		return result;
	}

	public void closeEmf() {
		em.close();
	}
	
	

}