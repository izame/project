package model;

import java.util.LinkedList;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQuery;

@Entity
@NamedQuery(name = "TipologiaEsame.findAll", query = "select distinct c from TipologiaEsame c")
public class TipologiaEsame {

	@Id
	private String code;
	
	@Column(nullable = false,unique=true)
	private String nome;
	
	@Column(nullable = false)
	private String descrizione;
	
	@Column(nullable = false)
	private float costo;
	
	@ManyToMany(fetch = FetchType.EAGER, cascade = { CascadeType.REMOVE, CascadeType.PERSIST })
	
	private List<Prerequisito> prerequisiti;
	
	@ManyToMany(fetch = FetchType.EAGER, cascade = { CascadeType.REMOVE, CascadeType.PERSIST })
	private List<Indicatore> indicatori;
	
	public TipologiaEsame(){
		
		this.prerequisiti = new LinkedList<>();
		this.indicatori = new LinkedList<>();
	}
	
	public TipologiaEsame(String nome, String descrizione, float costo) {
		super();
		this.nome = nome;
		this.descrizione = descrizione;
		this.costo = costo;
		this.prerequisiti = new LinkedList<>();
		this.indicatori = new LinkedList<>();
	}

	//utility
	public void addPrerequisito(Prerequisito prerequisito) {
		this.prerequisiti.add(prerequisito);
	}
	public void addIndicatore(Indicatore indicatore) {
		this.indicatori.add(indicatore);
	}


	//getter and setter
	
	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getDescrizione() {
		return descrizione;
	}

	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}

	public float getCosto() {
		return costo;
	}

	public void setCosto(float costo) {
		this.costo = costo;
	}

	public List<Prerequisito> getPrerequisiti() {
		return prerequisiti;
	}

	public void setPrerequisiti(List<Prerequisito> prerequisiti) {
		this.prerequisiti = prerequisiti;
	}

	public List<Indicatore> getIndicatori() {
		return indicatori;
	}

	public void setIndicatori(List<Indicatore> indicatori) {
		this.indicatori = indicatori;
	}

	@Override
	public String toString() {
		return "TipologiaEsame [code=" + code + ", nome=" + nome + ", descrizione=" + descrizione + ", costo=" + costo
				+ ", prerequisiti=" + prerequisiti + ", indicatori=" + indicatori + "]";
	}
	
}