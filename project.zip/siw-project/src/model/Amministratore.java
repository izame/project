package model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.NamedQueries;


@Entity(name="amministratore")
@NamedQueries({
	@NamedQuery(name = "Amministratore.findAll", query = "select c from amministratore c"),
	@NamedQuery(name = "Amministratore.findByMail", query = "select c .mail from amministratore c where c.mail =:mail"),		
})
public class Amministratore {

	@Id
	private String mail;

	@Column(nullable = false)
	private String password;

	@Column(nullable = false)
	private String nome;

	@Column(nullable = false)
	private String cognome;

	@Temporal(TemporalType.DATE)
	private Date dataDiNascita;


	//	costruttori
	public Amministratore(){}

	public Amministratore(String mail,String password,String nome,String cognome,Date dataDiNascita) {
		this.mail = mail;
		this.password = password;
		this.nome = nome;
		this.cognome = cognome;
		this.dataDiNascita = dataDiNascita;
	}
	//getter and setter

	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	public boolean verificaPassword(String password){
		return this.password.equals(password);
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCognome() {
		return cognome;
	}
	public void setCognome(String cognome) {
		this.cognome = cognome;
	}

	public Date getDataDiNascita() {
		return dataDiNascita;
	}

	public void setDataDiNascita(Date dataDiNascita) {
		this.dataDiNascita = dataDiNascita;
	}

	//toString

	@Override
	public String toString() {
		return "Amministratore [nome=" + nome + ", cognome=" + cognome + ", mail=" + mail + ", dataDiNascita=" + dataDiNascita + "]";
	}
}
