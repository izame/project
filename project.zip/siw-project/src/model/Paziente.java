package model;


import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity(name="paziente")

@NamedQuery(name = "Paziente.findByCodiceFiscale", query = "select distinct c from paziente c where c.codiceFiscale = :codiceFiscale")
public class Paziente{

	@Id
	private String codiceFiscale;
	
	private String nome;
	
	private String cognome;
	
	@Column(nullable = false)
	private String password;
	
	@Column(unique = true, nullable = false)
	private String email;
	
	@Temporal(TemporalType.DATE)
	private Date dataDiNascita;
	@OneToMany(fetch = FetchType.LAZY, cascade = { CascadeType.REMOVE, CascadeType.PERSIST })
	@JoinColumn(name = "paziente_id")
	private List<Esame> esami;
	
	public Paziente(){}
	
	public Paziente(String codiceFiscale, String nome, String cognome, String password, String email,	Date dataDiNascita) {
		this.nome = nome;
		this.cognome = cognome;
		this.password = password;
		this.email = email;
		this.codiceFiscale = codiceFiscale;
		this.dataDiNascita = dataDiNascita;
	}
	
	//getter and setter
	
	public String getNome() {
		return nome;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public String getCognome() {
		return cognome;
	}
	
	public void setCognome(String cognome) {
		this.cognome = cognome;
	}

	public boolean verificaPassword(String password) {
		return this.password == password;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getEmail() {
		return email;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getCodiceFiscale() {
		return codiceFiscale;
	}
	
	public void setCodiceFiscale(String codiceFiscale) {
		this.codiceFiscale = codiceFiscale;
	}
	
	public Date getDataDiNascita() {
		return dataDiNascita;
	}
	
	public void setDataDiNascita(Date dataDiNascita) {
		this.dataDiNascita = dataDiNascita;
	}

	public List<Esame> getEsami() {
		return esami;
	}

	public void setEsami(List<Esame> esami) {
		this.esami = esami;
	}

	//utility
	public void addEsame(Esame esame) {
		this.esami.add(esame);
	}

	//toString
	
	@Override
	public String toString() {
		return "Paziente [nome=" + nome + ", cognome=" + cognome + ", email=" + email
				+ ", codiceFiscale=" + codiceFiscale + ", dataDiNascita=" + dataDiNascita + ", esami=" + esami + "]";
	}










}