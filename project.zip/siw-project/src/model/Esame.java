package model;

import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;

@Entity(name="esame")
@NamedQueries({
	@NamedQuery(name = "Medico.findByIdMedico", query = "select distinct c from medico c where c.id = :id"),
	@NamedQuery(name = "Esame.findAll", query = "select e from esame e ")
})
public class Esame {

	@Id
	private String codice;

	@Column(nullable = false)
	private Date dataPrenotazione;

	@Column(nullable = false)
	private Date dataEsame;

	@ManyToOne(fetch = FetchType.LAZY, cascade = { CascadeType.REMOVE, CascadeType.PERSIST })
	private Medico medico;

	@ManyToOne(fetch = FetchType.LAZY, cascade = { CascadeType.REMOVE, CascadeType.PERSIST })
	private TipologiaEsame tipologiaEsame;

	@OneToMany(fetch = FetchType.LAZY, cascade = { CascadeType.REMOVE, CascadeType.PERSIST })
	@JoinColumn(name = "risultato_id")
	private List<Risultato> risultati;


	public Esame(){}
	
	public Esame(Date dataPrenotazione, Date dataEsame, Medico medico, TipologiaEsame tipologiaEsame) {
		this.dataPrenotazione = dataPrenotazione;
		this.dataEsame = dataEsame;
		this.medico = medico;
		this.tipologiaEsame = tipologiaEsame;
		this.risultati = new LinkedList<>();
	}

	//getter and setter

	public String getCodice() {
		return codice;
	}
	public void setCodice(String codice) {
		this.codice = codice;
	}

	public Date getDataPrenotazione() {
		return dataPrenotazione;
	}

	public void setDataPrenotazione(Date dataPrenotazione) {
		this.dataPrenotazione = dataPrenotazione;
	}

	public Date getDataEsame() {
		return dataEsame;
	}

	public void setDataEsame(Date dataEsame) {
		this.dataEsame = dataEsame;
	}

	public Medico getMedico() {
		return medico;
	}

	public void setMedico(Medico medico) {
		this.medico = medico;
	}

	public TipologiaEsame getTipologiaEsame() {
		return tipologiaEsame;
	}

	public void setTipologiaEsame(TipologiaEsame tipologiaEsame) {
		this.tipologiaEsame = tipologiaEsame;
	}

	public List<Risultato> getRisultati() {
		return risultati;
	}

	public void setRisultati(List<Risultato> risultati) {
		this.risultati = risultati;
	}

	//utility
	public void addRisultato(Risultato risultato) {
		this.risultati.add(risultato);
	}

}