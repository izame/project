package model;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity(name="medico")
@NamedQueries({
	@NamedQuery(name = "Medico.findAll", query = "select distinct c from medico c"),
	@NamedQuery(name = "Medico.findByCodiceFiscale", query = "select distinct c from medico c where c.codiceFiscale = :codiceFiscale")
})
public class Medico {

	

	@Id
	private String codiceFiscale;
	
	@Column(nullable = false)
	private String nome;
	
	@Column(nullable = false)
	private String cognome;

	@Column(nullable = false)
	private String password;

	@Column(unique = true, nullable = false)
	private String email;

	@Temporal(TemporalType.DATE)
	private Date dataDiNascita;

	@ManyToMany(fetch = FetchType.LAZY, cascade = { CascadeType.MERGE, CascadeType.REMOVE, CascadeType.PERSIST })
	private List<Specializzazione> specializzazioni;

	@OneToMany(fetch = FetchType.LAZY, cascade = {CascadeType.REMOVE, CascadeType.MERGE, CascadeType.PERSIST })
	@JoinColumn(name = "medico_id")
	private List<Esame> esamiEffettuati;

	//costruttori
	public Medico(String codiceFiscale, String nome, String cognome, String password, String email, Date dataDiNascita) {
		this.codiceFiscale = codiceFiscale;
		this.nome = nome;
		this.cognome = cognome;
		this.password = password;
		this.email = email;
		this.dataDiNascita = dataDiNascita;
	}
	public Medico(){}

	//getter and setter
	
	public String getCodiceFiscale() {
		return codiceFiscale;
	}
	
	public void setCodiceFiscale(String codiceFiscale) {
		this.codiceFiscale = codiceFiscale;
	}
	
	public String getNome() {
		return nome;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public String getCognome() {
		return cognome;
	}
	
	public void setCognome(String cognome) {
		this.cognome = cognome;
	}
	
	public boolean verificaPassword(String password) {
		return this.password == password;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getEmail() {
		return email;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	public Date getDataDiNascita() {
		return dataDiNascita;
	}
	
	public void setDataDiNascita(Date dataDiNascita) {
		this.dataDiNascita = dataDiNascita;
	}
	
	public void setEsamiEffettuati(List<Esame> esamiEffettuati) {
		this.esamiEffettuati = esamiEffettuati;
	}

	public void setSpecializzazioni(List<Specializzazione> specializzazioni) {
		this.specializzazioni = specializzazioni;
	}

	public List<Specializzazione> getSpecializzazioni() {
		return specializzazioni;
	}

	//utility
	public void addSpecializzazione(Specializzazione specializzazione) {
		this.specializzazioni.add(specializzazione);
	}
	
	public void addEsameEffettuato(Esame esameEffettuato) {
		this.esamiEffettuati.add(esameEffettuato);
	}

	//getter and setter
	public List<Esame> getEsamiEffettuati() {
		return esamiEffettuati;
	}







}