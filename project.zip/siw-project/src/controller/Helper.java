package controller;

import java.util.Calendar;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.servlet.http.HttpServletRequest;

import model.Amministratore;
import model.Esame;
import model.Medico;
import model.Paziente;
import model.TipologiaEsame;
import persistence.AmministratoreDao;
import persistence.EsameDao;
import persistence.MedicoDao;
import persistence.PazienteDao;
import persistence.TipologiaEsameDao;

public class Helper {


	public List<TipologiaEsame> acquisisciTipologieEsami(EntityManager em){
		TipologiaEsameDao tipologiaEsameDao = new TipologiaEsameDao(em);
		List<TipologiaEsame> tipologieEsami = new LinkedList<>();
		tipologieEsami.addAll(tipologiaEsameDao.findAll());
		return tipologieEsami;
	}
	public List<Medico> acquisisciListaMedici(EntityManager em){
		MedicoDao MedicoDao = new MedicoDao(em);
		List<Medico> medici = new LinkedList<>();
		medici.addAll(MedicoDao.findAll());
		return medici;
	}
	public List<Esame> acquisisciListaEsami(EntityManager em){
		EsameDao EsameDao = new EsameDao(em);
		List<Esame> esami = new LinkedList<>();
		esami.addAll(EsameDao.findAll());
		return esami;
	}
	public Esame acquisisciEsame(EntityManager em, String id){
		EsameDao esameDao = new EsameDao(em);
		return esameDao.findByPrimaryKey(id);

	}

	public Amministratore acquisisciAmministratore(EntityManager em, String mail){
		AmministratoreDao amministratoreDao = new AmministratoreDao(em);
		return amministratoreDao.findByPrimaryKey(mail);

	}

	public String autenticaAmministratore(EntityManager em, HttpServletRequest request){
		Amministratore amministratore = acquisisciAmministratore(em, request.getParameter("mail"));
		String nextPage = "/areaRiservata.jsp";

		if(validateAutenticazione(request)){
			if (amministratore==null){
				nextPage = "/areaRiservata.jsp";
				request.setAttribute("erroreMail", "non è stato trovato un amministratore "
						+ "associato alla mail inserita");
			}
			if(!amministratore.verificaPassword(request.getParameter("password"))){
				nextPage = "/areaRiservata.jsp";
				request.setAttribute("errorePassword", "password inserita non valida");
			}
			if(amministratore.verificaPassword(request.getParameter("password"))){
				nextPage = "/paginaAmministrazione.jsp";
			}
		}
		return nextPage;
	}

	public boolean validateAutenticazione(HttpServletRequest request) {

		boolean corretto=true;
		String password = request.getParameter("password");
		String mail = request.getParameter("mail");
		if(password.equals("")){
			request.setAttribute("passwordError","password: campo obligatorio");	
			corretto = false;
		}

		if(mail.equals("")){
			corretto = false;
			request.setAttribute("mailError","mail: campo obligatorio");			
		}


		return corretto;
	}

	public boolean creaEsame(EntityManager em,HttpServletRequest request) {
		PazienteDao pazienteDao = new PazienteDao(em);
		Paziente paziente = pazienteDao.findByCodiceFiscale(request.getParameter("cfPaziente"));
		MedicoDao medicoDao = new MedicoDao(em);
		Medico medico = medicoDao.findByCodiceFiscale(request.getParameter("cfMedico"));
		if(medico==null){
			request.setAttribute("erroreMedico","il codice fiscale inserito non è associato a nessun medico della clinica.");
			return false;
		}
		if(paziente==null){
			request.setAttribute("errorePaziente","il codice fiscale inserito non è associato a nessun paziente della clinica.");
			return false;
		}
		Calendar calendarPrenotazione = Calendar.getInstance();
		Date dataPrenotazione = calendarPrenotazione.getTime();
		Date dataEsame = prendiDataEsame(request);
		TipologiaEsame tipologiaEsame =(TipologiaEsame) request.getAttribute("tipologiaEsame");
		Esame nuovoEsame=new Esame(dataPrenotazione,dataEsame,medico,tipologiaEsame);
		paziente.addEsame(nuovoEsame);
		medico.addEsameEffettuato(nuovoEsame);//effettuare questo dopo che l'esame è stato effettuato?
		
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		pazienteDao.update(paziente);
		medicoDao.update(medico);
		tx.commit();
		
		return true;
	}
	public Date prendiDataEsame(HttpServletRequest request){
		int anno = new Integer(request.getParameter("annoEsame"));
		int mese = new Integer(request.getParameter("meseEsame"));
		int giorno = new Integer(request.getParameter("giornoEsame"));
		int ora = new Integer(request.getParameter("oraEsame"));
		int minuto = new Integer(request.getParameter("minutiEsame"));
		Calendar cal = Calendar.getInstance();
		cal.set(anno, mese, giorno, ora, minuto, 0);
		return cal.getTime();

	}

	public String risultatiEsame(EntityManager em,HttpServletRequest request) {
		Esame esame = acquisisciEsame(em,request.getParameter("codice"));
		String nextPage="gestisciEsami.jsp";
		if(esame==null){
			nextPage="gestisciEsami.jsp";
			request.setAttribute("erroreEsame", "non è stato trovato nessun esame relativo a quel codice");
		}
		nextPage="inserisciRisultatiEsame.jsp";
		return nextPage;
	}
}


