package controller;


import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.servlet.http.HttpServletRequest;

import model.Esame;
import model.Medico;
import model.TipologiaEsame;




public class Facade {
	
	private EntityManagerFactory entityManagerFactory;
	private EntityManager entityManager;
	
	public Facade() {
		this.entityManagerFactory = Persistence.createEntityManagerFactory("clinica");
		this.entityManager = this.entityManagerFactory.createEntityManager();
	}
	public EntityManager getEntityManager() {
		return entityManager;
	}
	public List<TipologiaEsame> aquisisciTipologieEsami(){
		return new controller.Helper().acquisisciTipologieEsami(this.entityManager);
	}
	public List<Medico> aquisisciListaMedici(){
		return new controller.Helper().acquisisciListaMedici(this.entityManager);
	}
	public List<Esame> aquisisciListaEsami(){
		return new controller.Helper().acquisisciListaEsami(this.entityManager);
	}
	
	public String autenticaAmministratore(HttpServletRequest request){
		return new controller.Helper().autenticaAmministratore(this.entityManager, request);
	}
	public String risultatiEsame(HttpServletRequest request){
		return new controller.Helper().risultatiEsame(this.entityManager, request);
	}
	
	public boolean creaEsame(HttpServletRequest request) {
		return new controller.Helper().creaEsame(this.entityManager,request);
		
	}

	public void close(){
		this.entityManager.close();
		this.entityManagerFactory.close();
	}

	
}